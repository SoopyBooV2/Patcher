package club.sk1er.patcher.hooks;

import club.sk1er.patcher.screen.render.overlay.metrics.MetricsData;

public class MinecraftServerHook {
    public static MetricsData metricsData;
}
