package club.sk1er.patcher.ducks;

public interface EntityFXExt {
    void patcher$setCullState(float cullState);
    float patcher$getCullState();
}
