package club.sk1er.patcher.hooks;

public class ItemRendererHook {
    public static boolean isRenderingItemInFirstPerson;
}
