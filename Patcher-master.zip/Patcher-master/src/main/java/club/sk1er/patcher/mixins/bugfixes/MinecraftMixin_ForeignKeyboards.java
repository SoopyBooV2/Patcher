package club.sk1er.patcher.mixins.bugfixes;

import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(Minecraft.class)
public class MinecraftMixin_ForeignKeyboards {
    //#if MC==10809
    @Redirect(method = "dispatchKeypresses", at = @At(value = "INVOKE", target = "Lorg/lwjgl/input/Keyboard;getEventCharacter()C", remap = false))
    private char patcher$resolveForeignKeyboards() {
        return (char) (Keyboard.getEventCharacter() + 256);
    }
    //#endif
}
