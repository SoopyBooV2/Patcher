package club.sk1er.patcher.ducks;

public interface VisGraphExt {
    void patcher$setLimitScan(boolean limitScan);
}
