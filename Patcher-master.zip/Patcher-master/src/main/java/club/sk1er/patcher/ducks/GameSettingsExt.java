package club.sk1er.patcher.ducks;

public interface GameSettingsExt {
    void patcher$onSettingsGuiClosed();
}
