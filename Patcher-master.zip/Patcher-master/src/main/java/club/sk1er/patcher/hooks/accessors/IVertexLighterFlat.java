package club.sk1er.patcher.hooks.accessors;

import net.minecraftforge.client.model.pipeline.BlockInfo;

@SuppressWarnings("unused")
public interface IVertexLighterFlat {
    BlockInfo getBlockInfo();
}
